const express=require('express');
const cors=require('cors');
const app=express();
app.use(cors());
const movies=require('./movies_metadata.json');
app.get('/api/movies',(req,res)=>res.json(movies));
app.listen(5000,()=>console.log('Server running on port 5000'));