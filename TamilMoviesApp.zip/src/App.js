import React,{useEffect,useState} from 'react';
import './App.css';
export default function App(){
 const [movies,setMovies]=useState([]);
 useEffect(()=>{
  fetch('http://localhost:5000/api/movies')
   .then(r=>r.json())
   .then(setMovies);
 },[]);
 return (
  <div className='app'>
   <h1>Tamil Movies Collection</h1>
   <div className='movies-grid'>
    {movies.map(movie=>(
      <div className='movie-card' key={movie.id}>
       <h2>{movie.title}</h2>
       <p>{movie.tagline}</p>
       <p>Director: {movie.director}</p>
       <p>Rating: {movie.vote_average}/10</p>
      </div>
    ))}
   </div>
  </div>
 );
}